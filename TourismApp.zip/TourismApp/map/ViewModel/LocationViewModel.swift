//
//  LocationViewModel.swift
//  TourismApp
//
//  Created by ِatheer on 18/07/1444 AH.
//

import Foundation
import MapKit
import SwiftUI

class LocationViewModel: ObservableObject {
    //all locations I added in (Locations data file )
    @Published var locations : [Location]
    //to display the current location
    @Published var currenLocation : Location {
        //to runs a piece of code right every time the property currenLocation has changed
        didSet{
            updateCurrentLocation(location: currenLocation)
        }
    }
    
    //current region on map
    @Published var Region : MKCoordinateRegion = MKCoordinateRegion()
    let mapSpan = MKCoordinateSpan(latitudeDelta: 0.1 , longitudeDelta: 0.1)
    
    //to display a list name of city , by defult when i open the app will not show the list
    @Published var dispalyLocationList : Bool = false
    
    //show location details when i swip up page by using sheet
    @Published var sheet : Location? = nil
    init() {
        let locations = LocationData.locations
        self.locations = locations
        self.currenLocation = locations.first! // to display the first element of the collection
        self.updateCurrentLocation(location: locations.first!)
    }
   
    private func updateCurrentLocation(location: Location)
    {
            withAnimation(.easeInOut){
            Region = MKCoordinateRegion(
            center : location.coordinates ,
            span:mapSpan)
        }
        
    }
    
     func toggleLocationList() {
         withAnimation(.easeInOut){
             //    showLocationsList = !showLocationsList // it means not false = true So will display the list of item
             dispalyLocationList.toggle()
        }
    }
    //to change the current location and move to the next location
    func displaySubsequentLocation (location : Location){
        withAnimation(.easeInOut){
          currenLocation = location
            dispalyLocationList = false
        }
    }
}

