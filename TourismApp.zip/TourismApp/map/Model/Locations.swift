//
//  Locations.swift
//  TourismApp
//
//  Created by ِatheer on 18/07/1444 AH.
//

import Foundation
import MapKit // to use info about coordinate

struct Location: Identifiable , Equatable {
    let id = UUID().uuidString // to generate difiirent id for every location
    let name : String
    let CityName : String
    let coordinates : CLLocationCoordinate2D // to the latitude and longitude associated with a location
    let description : String
    let ImageList : [String]
    let URL : String
    

    // Equatable
    static func == (lhs: Location, rhs: Location) -> Bool {
        lhs.id == rhs.id
    }
  
}
