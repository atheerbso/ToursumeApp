//
//  ViewMap.swift
//  TourismApp
//
//  Created by ِatheer on 18/07/1444 AH.
//

import SwiftUI

struct ViewMap: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ViewMap_Previews: PreviewProvider {
    static var previews: some View {
        ViewMap()
    }
}
