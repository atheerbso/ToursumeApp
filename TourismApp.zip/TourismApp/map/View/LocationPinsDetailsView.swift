
//
//  LocationDetailsView.swift
//  TourismApp
//
//  Created by ِatheer on 19/07/1444 AH.
//

import SwiftUI
import MapKit
//customaiz the pins over map
struct LocationPinsDetailsView: View {
    
    let location : Location
    @EnvironmentObject private var viewModelObject : LocationViewModel
    var body: some View {
        HStack(alignment: .bottom, spacing: 0){
            VStack(spacing: 20){
                //coustomaize the images
                ZStack{
                    if let imgName = location.ImageList.first{
                        Image(imgName)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100 , height: 100)
                            .cornerRadius(10)
                    }
                }//end Z
                .padding(5)
                .background(.white)
                .cornerRadius(10)
                .shadow(radius: 5 , x:5 ,y:5 )
                
                
                //Customaize title
                VStack(alignment: .leading, spacing: 4){
                    Text(location.name)
                        .font(.title3)
                        .fontWeight(.bold)
                    Text(location.CityName)
                        .font(.title3)
                        .fontWeight(.medium)
                }//end vs
                .multilineTextAlignment(.center)
            }
          
            //end main vst
            VStack (spacing: 8){
                Button {
                    viewModelObject.sheet = location
                } label: {
                 Text("إقرأ المزيد")
                        .font(.headline)
                        .frame(width: 125 , height: 35)
                        .foregroundColor(.secondary)
                        .fontWeight(.heavy)
                        .background(.ultraThinMaterial)
                        .cornerRadius(5)
                        .shadow(radius: 5 , x:5, y:5)
                        .padding(.bottom ,50)
                }
                .offset(x:7)
    
            }//end vs
           
        }//end hs
        .padding(20)
        .frame(maxWidth: .infinity)
        .background(
        RoundedRectangle(cornerRadius: 10)
            .fill(.ultraThinMaterial)
        .shadow(radius: 5 , x:5 , y:5)
        .offset(y:65)
        )
        .cornerRadius(10)
    }
        
}

struct LocationDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        LocationPinsDetailsView(location: LocationData.locations.first!)
            .padding()
        
    }
}
