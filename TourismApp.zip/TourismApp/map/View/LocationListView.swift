//
//  LocationListView.swift
//  TourismApp
//
//  Created by ِatheer on 18/07/1444 AH.
//

import SwiftUI
import MapKit

struct LocationListView: View {
    @EnvironmentObject private var viewModelList : LocationViewModel
    var body: some View {
        List{
                ForEach(viewModelList.locations){ locationIndex in
                    Button {
                        //to moveing between pins , (Didnt work return to it (ved5))
                        viewModelList.displaySubsequentLocation(location: locationIndex)
                    } label: {
                        HStack{
                            //list views
                            if let imageName = locationIndex.ImageList.first{
                                Image(imageName)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 45 , height: 45)
                                    .cornerRadius(10)
                            }
                            VStack(alignment: .leading){
                                Text(locationIndex.name)
                                    .font(.headline)
                                Text(locationIndex.CityName)
                                    .font(.subheadline)
                            }
                            .frame(maxWidth: .infinity , alignment: .leading)
                        }//end hst
                    }//end label
                .padding(20)
                }// end of foreach
            
        } // the end of list
        .listStyle(PlainListStyle())
        
    }
}

struct LocationListView_Previews: PreviewProvider {
    static var previews: some View {
        LocationListView()
            .environmentObject(LocationViewModel())
    }
}
