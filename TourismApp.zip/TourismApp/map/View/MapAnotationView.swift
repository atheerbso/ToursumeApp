//
//  MapAnotationView.swift
//  TourismApp
//
//  Created by ِatheer on 20/07/1444 AH.
//

import SwiftUI

struct MapAnotationView: View {
    var body: some View {
        VStack(spacing: 0) {
                  Image(systemName: "mappin.and.ellipse")
                      .resizable()
                      .scaledToFit()
                      .frame(width: 30, height: 30)
                      .font(.headline)
                      .foregroundColor(.red)
                      .padding(6)

              }
    }
}

struct MapAnotationView_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            MapAnotationView()
        }
    }
}
