//
//  locationView.swift
//  TourismApp
//
//  Created by ِatheer on 18/07/1444 AH.
//

import SwiftUI
import MapKit

struct locationView: View {
    @EnvironmentObject private var viewModelObject : LocationViewModel
//    @State private var Region : MKCoordinateRegion = MKCoordinateRegion(
//        //احدد المركز من الخريطة
//        center : CLLocationCoordinate2D(latitude: 41.8902, longitude: 12.4922), span: MKCoordinateSpan(latitudeDelta: 0.1 , longitudeDelta: 0.1)
//    )
    var body: some View {
        
        ZStack{
            mapLayer
            //create the map that display the coordinate region + annotation(pins) and thier content
               
            Map(coordinateRegion: $viewModelObject.Region, annotationItems: viewModelObject.locations , annotationContent: {
                Location in
                
               // MapMarker(coordinate: Location.coordinates, tint: .red) // to add pins on map and customaize color
                //the second way to add pins but with content :
                MapAnnotation(coordinate: Location.coordinates){
                
                    MapAnotationView()
                        .scaleEffect(viewModelObject.currenLocation == Location ? 1.5: 0.7)//to change pin size when in the center
            .shadow(radius: 10)
            .onTapGesture {
                //to move to next location when i press on pin 
                viewModelObject.displaySubsequentLocation(location: Location)
            }
                    
                }
                
            })
            .ignoresSafeArea()
            VStack (spacing: 0){
                //NameCitySetion
                VStack{
                    Button(action: viewModelObject.toggleLocationList) {
                        
                        Text(viewModelObject.currenLocation.name + " , " + viewModelObject.currenLocation.CityName)
                            .font(.system(size: 20))
                            .fontWeight(.bold)
                            .foregroundColor(.primary.opacity(0.6))
                            .frame(maxWidth: .infinity)
                            .padding(20)
                            .overlay(alignment: .leading){
                                Image(systemName: "arrow.down")
                                    .font(.title3)
                                    .foregroundColor(.primary)
                                    .padding()
                                //this modfier to change th direction of arrow when i toggle the derction move to 180 degree else dosent chage (0 degree )
                                    .rotationEffect(Angle(degrees: viewModelObject.dispalyLocationList ? 180 : 0))
                            }
                    }
                    if viewModelObject.dispalyLocationList{
                        LocationListView()
                    }
                    
                }
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                .shadow(radius: 5 , x:5 , y:5)
                .padding()
                
                Spacer()
                
                ZStack{
                    ForEach(viewModelObject.locations){location in
                       if viewModelObject.currenLocation == location {
                            LocationPinsDetailsView(location: location)
                                .padding()
                                .transition(.asymmetric(insertion: .move(edge: .trailing), removal: .move(edge: .leading)))
                      }
                    }
                }
                
            }
            .sheet(item: $viewModelObject.sheet , onDismiss: nil){ Location in
                DetailsView(location: Location)
                
            }
        }
    }
    
    private var mapLayer: some View {
        Map(coordinateRegion: $viewModelObject.Region,
            annotationItems: viewModelObject.locations,
              annotationContent: { location in
              MapAnnotation(coordinate: location.coordinates) {
                  MapAnotationView()
                      .scaleEffect(viewModelObject.currenLocation == location ? 1 : 0.7)
                      .shadow(radius: 10)
                      .onTapGesture {
                          viewModelObject.displaySubsequentLocation(location: location)
                      }
              }
          })
      }
}

struct locationView_Previews: PreviewProvider {
    static var previews: some View {
        locationView()
            .environmentObject(LocationViewModel())
    }
}

//extension locationView{
//
//    private var NameCitySetion : some View {
//
//        VStack{
//            Text(viewModelObject.currenLocation.name + " , " + viewModelObject.currenLocation.CityName)
//                .font(.system(size: 25))
//                .fontWeight(.bold)
//                .foregroundColor(.primary.opacity(0.6))
//                .frame(width: 250 , height: 60)
//        }
//        .background(.ultraThinMaterial)
//        .cornerRadius(20)
//        .shadow(radius: 5 , x:5 , y:5)
//    }
//}
