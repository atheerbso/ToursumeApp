//
//  DetailsView.swift
//  TourismApp
//
//  Created by ِatheer on 20/07/1444 AH.
//

import SwiftUI

struct DetailsView: View {
    let location : Location
    @State var selection: Int? = nil
    @EnvironmentObject private var viewModelObject : LocationViewModel
    var body: some View {
      
        ScrollView {
            VStack{
                
                imagePart
                    .shadow(color: Color.black.opacity(0.5) ,radius:20 , x:0 , y:10)
                
                VStack(alignment: .center , spacing: 15){
                    titlePart
                    Divider()
                    descriptionPart
                    Divider()
                }
                .frame(maxWidth: .infinity , alignment: .trailing)
                .padding()
                
            }
            //tabBar()
        }
        .ignoresSafeArea()
        .overlay(HeaderIcons , alignment: .topLeading)
       
        
            
     
    }
    
}

struct DetailsView_Previews: PreviewProvider {
    static var previews: some View {
        DetailsView(location : LocationData.locations.first!)
    }
}

extension DetailsView {
    private var imagePart : some View {
        TabView{
            ForEach(location.ImageList, id: \.self){
                //$0 to refrencre to each index in image list
                Image($0)
                    .resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width)
                    .clipped()
            }
            
        }
        .frame(height: 500)
        .tabViewStyle(PageTabViewStyle())
    }
    private var titlePart : some View {
        VStack(alignment: .center , spacing: 8){
            Text(location.name)
                .font(.title)
                .fontWeight(.semibold)
            Text(location.CityName)
                .font(.title3)
                .foregroundColor(.secondary)
        }
        .multilineTextAlignment(.center)
    }
    
    private var descriptionPart : some View {
        VStack(alignment: .center , spacing: 8){
            Text(location.description)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            if let url = URL(string: location.URL) //this step to convert url from string to url
            {
                Link("إقرأ المزيد حول هذا المكان" , destination: url)
                    .font(.headline)
                    .tint(.cyan)
            }
        }
        .multilineTextAlignment(.center)
       
    }
    
    private var HeaderIcons : some View {
        HStack{
            Button{
                viewModelObject.sheet = nil
            }label:{
                Image(systemName: "xmark")
                    .font(.headline)
                    .padding(16)
                    .foregroundColor(.primary)
                    .background(.thickMaterial)
                    .cornerRadius(50)
                    .shadow(radius: 20)
                    .padding()
            }
            
            Spacer()
            NavigationLink(destination: logInView(), tag: 1, selection: $selection) {
                Button{
                    
                }label:{
                    Image(systemName: "person")
                        .font(.headline)
                        .padding(16)
                        .foregroundColor(.primary)
                        .background(.thickMaterial)
                        .cornerRadius(50)
                        .shadow(radius: 20)
                        .padding()
                }
            }
        }
    }
} //extention
