
//
//  loginView.swift
//  TourismApp
//
//  Created by ِatheer on 16/07/1444 AH.
//


import SwiftUI
import Firebase

struct SignUpView: View {
    @State  var email = ""
    @State  var password  = ""
    @State private var userLoggedIn = false
    
    var body: some View {
        ZStack{
            Color(.white)
                .frame(width: 350, height: 500)
                .cornerRadius(20)
                .shadow(radius: 10 , x:5, y:5)
            
            VStack (spacing: 20){
                Text("مرحباً بك")
                    .foregroundColor(.primary)
                    .fontWeight(.bold)
                    .font(.system(size: 35))
                    .padding(.bottom,40)
                VStack (spacing: 20){
                    TextField("  Enter Your Email ", text: $email)
                        .frame(width: 300, height: 50)
                        .background(.secondary.opacity(0.1))
                        .cornerRadius(5)
                        .padding(.trailing,30)
                        .foregroundColor(.primary)
  
                    
                    SecureField("  Enter Your Password" ,text: $password)
                        .frame(width: 300, height: 50)
                        .background(.secondary.opacity(0.1))
                        .cornerRadius(5)
                        .padding(.trailing,30)
                        .foregroundColor(.primary)
                    
                    
                }
                .padding(.leading , 40)
                
                
                Button{
                    SignUp()
                }label: {
                    Text("سـجل الآن")
                        .frame(width: 180 , height: 45)
                        .foregroundColor(.secondary)
                        .fontWeight(.heavy)
                        .background(.ultraThinMaterial)
                        .cornerRadius(5)
                        .shadow(radius: 5 , x:5, y:5)
                        .padding(30)
                    
                }
                .padding(.top,20)
                
                Button{
                    logIn()
                }label: {
                    
                    Text("هل لديك حساب مُنشئ سابقاً ؟ سجل دخول ")
                        .foregroundColor(.secondary)
                        .font(.system(size: 15))
                        .fontWeight(.light)
                }
                .padding(.top,50)
                
            }
            }
            .frame(width: 350)
            .onAppear(){
                Auth.auth().signIn(withEmail: email, password: password){ result, error in
                    if error != nil{
                        print(error!.localizedDescription)
                    }
                    
                }
          
        }
    }
    
    func logIn(){
        Auth.auth().signIn(withEmail: email, password: password){result , error in
            if error != nil {
                print(error!.localizedDescription)
            }
        }
    }
    func SignUp(){
        Auth.auth().createUser(withEmail: email, password: password){result , error in
            if error != nil {
                print(error!.localizedDescription)
            }
        }
    }
}

//extension View {
//    func placeholder<Content : View>(
//        when shouldShow : Bool ,
//        alignment : Alignment = .leading ,
//        @ViewBuilder placeholder: () -> Content) -> some View {
//
//            ZStack(alignment: alignment){
//                placeholder().opacity(shouldShow ? 1 : 0)
//                    .self
//            }
//        }
//
//}
struct loginView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
