//
//  logInView.swift
//  TourismApp
//
//  Created by ِatheer on 19/07/1444 AH.
//

import SwiftUI
import Firebase

struct logInView: View {
    @State var show = false
    var body: some View {
        Home()
//        NavigationView{
//            ZStack{
//                NavigationLink(destination : SignUp(show : self.$show) , isActive :self.$show ){
//                    Text("")
//                }
//                .hidden()
//                Login(show : self.$show)
//            }
//        }
    }
}

struct logInView_Previews: PreviewProvider {
    static var previews: some View {
        logInView()
    }
}

struct Home : View {
    @State var show = false
    @State var status = UserDefaults.standard.value(forKey: "status")as? Bool ?? false
    var body : some View {
        NavigationView{
            VStack{
                if self.status {
                    
                    HomeScreen()
                }
                else
                {
                    ZStack{
                        NavigationLink(destination : SignUp(show : self.$show) , isActive :self.$show ){
                          
                        }
                        .hidden()
                        Login(show : self.$show)
                    }
                }
            }
            .navigationBarTitle("")
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
            .onAppear{
                
                NotificationCenter.default.addObserver(forName: NSNotification.Name("status"), object: nil, queue: .main ){
                    (_)in
                    
                    self.status = UserDefaults.standard.value(forKey: "status")as? Bool ?? false
                }
            }
        }
    }
}


struct HomeScreen : View {
    var body : some View {
        VStack{
            Text("تم تسجيل الدخول بنجاح !")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(Color.black.opacity(0.7))
            
            Button(action: {
                try! Auth.auth().signOut()
                UserDefaults.standard.set(false , forKey: "status")
                NotificationCenter.default.post(name: NSNotification.Name("status"),object: nil)
            }){
                Text(" سجل خروج")
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.vertical)
                    .frame(width: UIScreen.main.bounds.width - 50 )
                
            }
            .background(.primary)
            .cornerRadius(10)
            .padding(.top ,25)
        }
    }
    
}
struct Login : View{
    
    @State var color = Color.black.opacity(0.7)
    @State var email = ""
    @State var pass = ""
    @State var visable = false
    @Binding var show : Bool
    @State var alert = false
    @State var error = ""
    
    var body : some View {
        ZStack{
            ZStack(alignment: .topTrailing){
                GeometryReader {_ in
                    VStack{
                        Image(systemName: "person")
                            .resizable()
                            .frame(width: 100,height: 100)
                            .padding(.top,150)
                        Text("سجل دخول إلى حسابك")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(self.color)
                            .padding(.top, 35)
                        
                        TextField("Email", text:self.$email)
                            .autocapitalization(.none)
                            .padding()
                            .background(RoundedRectangle(cornerRadius:4).stroke(self.email != "" ? Color(""): self.color,lineWidth :2 ))
                            .padding(.top ,25)
                        
                        HStack(spacing: 15){
                            VStack{
                                if self.visable{
                                    TextField("password" , text: self.$pass)
                                        .autocapitalization(.none)
                                }
                                else{
                                    SecureField("password" , text: self.$pass)
                                        .autocapitalization(.none)
                                }
                            }// end v
                            Button(action:  {
                                self.visable.toggle()
                            }){
                                Image(systemName: self.visable ? "eye.slash.fill": "eye.fill" ) .foregroundColor(self.color)
                            }
                        } //end Ht
                        .padding()
                        .background(RoundedRectangle(cornerRadius:4).stroke(self.pass != "" ? Color(""): self.color,lineWidth :2 ))
                        .padding(.top ,25)
                        HStack{
                            Spacer()
                            Button(action: {
                                self.reset()
                            }) {
                                Text("هل نسيت الرقم السري ؟")
                                    .fontWeight(.bold)
                                    .foregroundColor(Color(.red))
                            }
                            Spacer()
                        }
                        .padding(.top ,20)
                        
                        Button(action: {
                            
                            self.verify()
                        }){
                            Text(" سجل دخول")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50 )
                            
                        }
                        .background(.primary)
                        .cornerRadius(10)
                        .padding(.top ,25)
                    }//end main vs
                    .padding(.horizontal , 25)
                }//end geo
                Button(action: {
                    self.show.toggle()
                }){
                   Text("سجل الآن ")
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                }
                .padding()
            }
            if self.alert {
                ErrorView(alert:self.$alert , error: self.$error)
            }
        }
    }
    func verify(){
        if self.email != "" && self.pass != ""{
            Auth.auth().signIn(withEmail: self.email, password: self.pass){
                (Result, err) in
                if err != nil {
                    
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                print("نجحت عملية تسجيل الدخول")
                UserDefaults.standard.set(true , forKey: "status")
                NotificationCenter.default.post(name:NSNotification.Name("status"),object: nil)
            }
        }
        else{
            self.error = "الرجاء تعبئة جميع الحقول"
            self.alert.toggle()
        }
    }
    func reset (){
        if self.email != "" {
            Auth.auth().sendPasswordReset(withEmail: self.email){
                (err) in
                if err != nil {
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                self.error = "إعادة تعيين الرقم السري"
                self.alert.toggle()
            }
            
        }
        else {
            self.error = "حقل الايميل فارغ"
            self.alert.toggle()
        }
    }
}


//=========

struct SignUp : View{
    
    @State var color = Color.black.opacity(0.7)
    @State var email = ""
    @State var pass = ""
    @State var reset = ""
    @State var visable = false
    @State var revisable = false
    @Binding var show : Bool
    @State var alert = false
    @State var error = ""
    var body : some View {
        ZStack{
            ZStack(alignment: .topLeading)
            {
                GeometryReader {_ in
                    VStack{
                        
                        Image(systemName: "person")
                            .resizable()
                            .frame(width: 100,height: 100)
                            .padding(.top,150)
                        Text("سجل دخول إلى حسابك")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(self.color)
                            .padding(.top, 35)
                        
                        TextField("Email", text:self.$email)
                            .autocapitalization(.none)
                            .padding()
                            .background(RoundedRectangle(cornerRadius:4).stroke(self.email != "" ? Color(""): self.color,lineWidth :2 ))
                            .padding(.top ,25)
                        
                        HStack(spacing: 15){
                            VStack{
                                if self.visable{
                                    TextField("password" , text: self.$pass)
                                        .autocapitalization(.none)
                                }
                                else{
                                    SecureField("password" , text: self.$pass)
                                        .autocapitalization(.none)
                                }
                            }// end v
                            Button(action:  {
                                self.visable.toggle()
                            }){
                                Image(systemName: self.visable ? "eye.slash.fill": "eye.fill" ) .foregroundColor(self.color)
                            }
                        } //end Ht
                        .padding()
                        .background(RoundedRectangle(cornerRadius:4).stroke(self.pass != "" ? Color(""): self.color,lineWidth :2 ))
                        .padding(.top ,25)
                        
                        HStack(spacing: 15){
                            VStack{
                                if self.revisable{
                                    TextField("Re-enter" , text: self.$reset)
                                        .autocapitalization(.none)
                                }
                                else{
                                    SecureField("Re-enter" , text: self.$reset)
                                        .autocapitalization(.none)
                                }
                            }// end v
                            Button(action:  {
                                self.revisable.toggle()
                            }){
                                Image(systemName: self.revisable ? "eye.slash.fill": "eye.fill" ) .foregroundColor(self.color)
                            }
                        } //end Ht 2
                        .padding()
                        .background(RoundedRectangle(cornerRadius:4).stroke(self.reset != "" ? Color(""): self.color,lineWidth :2 ))
                        .padding(.top ,25)
                
                        
                        Button(action: {
                            self.register()
                        }){
                            Text("انشاء حساب")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50 )
                            
                        }
                        .background(.primary)
                        .cornerRadius(10)
                        .padding(.top ,25)
                    }//end main vs
                    .padding(.horizontal , 25)
                }//end geo
                Button(action: {
                    self.show.toggle()
                }){
                  Image(systemName: "chevron.left")
                        .foregroundColor(.primary)
                        .font(.title)
                }
                .padding()
            }
            if self.alert{
                ErrorView(alert: self.$alert, error: self.$error)
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    func register(){
        //to sign up by firbase
        if self.email != "" {
            if self.pass == self.reset{
                Auth.auth().createUser(withEmail: self.email, password: self.pass){
                    (result ,err) in
                    if err != nil{
                        self.error = err!.localizedDescription
                        self.alert.toggle()
                    }
                    print ("تم انشاء الحساب بنجاح")
                    UserDefaults.standard.set(true , forKey: "status")
                    NotificationCenter.default.post(name:NSNotification.Name("status"),object: nil)
                }
            }
            else{
                self.error = "الرقم السري غير متطابق"
                self.alert.toggle()
                return
            }
        }
        else{
            self.error = "الرجاء تعبئة جميع الحقول "
            self.alert.toggle()
        }
    }
    
}



//=====

struct ErrorView : View{
    @Binding var alert : Bool
    @Binding var error : String
  
    var body : some View {
     
        GeometryReader{_ in
            VStack{
                HStack{
                    Spacer()
                    Text(self.error == "إعادة تعيين الرقم السري" ? "Message" : "Error")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                    
                 
                }
                .padding(.horizontal,25)
                
                Text(self.error == "إعادة تعيين الرقم السري" ?
                      "تم ارسال رابط تعيين الرقم السري "
                     : self.error)
                    .foregroundColor(.red)
                    .padding(.top)
                    .padding(.horizontal ,25)
                
                Button(action: {
                    self.alert.toggle()
                }) {
                    Text(self.error == "إعادة تعيين الرقم السري"
                 
                         ? "حسناً" : "الغاء")
                        .foregroundColor(.white)
                        .padding(.vertical)
                        .frame(width:UIScreen.main.bounds.width - 120)
                }
                .background(.primary)
                .cornerRadius(10)
                .padding(.top ,25)
            }
            .padding(.vertical,25)
            .frame(width: UIScreen.main.bounds.width - 70)
            .background(.white)
            .cornerRadius(15)
        }
        .background(Color.black.opacity(0.35).edgesIgnoringSafeArea(.all))
    }
}
