//
//  onbordingView.swift
//  TourismApp
//
//  Created by ِatheer on 15/07/1444 AH.
//

import SwiftUI

struct onbordingView{
    var image : String
    var description : String
}
private let sampleonbordingPages : [onbordingView] = [
    onbordingView(image: "bc1", description: "تخلص من دفق الأفكار \nالمتزاحمة  في ذهنك"),
    onbordingView(image: "bc2", description: "واستمتع بوقتك\n و اصنع ذكريات جميله مع من تحب"),
    onbordingView(image: "bc3", description: "تصفح الآن واختر وجهتك " )
]

//this page To Customaize the desigen
struct OnbordingView: View  {
    @State private var currentCount = 0
    @State var selection: Int? = nil
    init(){
        UIScrollView.appearance().bounces = false
    }
    var body: some View {
        
//        NavigationView {
//
//            NavigationLink(destination: locationView()) {
                
                VStack{

                    ScrollView {
                        TabView (selection: $currentCount){
                            ForEach(0..<sampleonbordingPages.count ){index in
                                ZStack{
                                    VStack{
                                        Image(sampleonbordingPages[index].image)
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .opacity(0.7)
                                        
                                    }
                                    
                                    VStack{
                                        Text(sampleonbordingPages[index].description)
                                            .foregroundColor(.white)
                                            .font(.system(size: 20))
                                            .fontWeight(.heavy)
                                            .multilineTextAlignment(.center)
                                    }
                                    .padding(.top ,-30)
                                    .frame(width: 300, height: 200, alignment: .center)
                                    .background(.ultraThinMaterial)
                                    .cornerRadius(10)
                                    .shadow(radius: 10 , x:5 ,y:5)
                                    VStack{
                                        HStack{
                                            //for dots
                                            ForEach(0..<sampleonbordingPages.count){index in
                                                if index == currentCount {
                                                    Rectangle()
                                                        .frame(width: 20 , height: 10)
                                                        .cornerRadius(10)
                                                    .foregroundColor(.white) }
                                                else {
                                                    Circle()
                                                        .frame(width :10 , height: 10)
                                                        .foregroundColor(.secondary)
                                                }
                                            }
                                        }//end h
                                        .padding(.top ,700)
                                        
                                    }
                                    
                                    VStack{
//                                        NavigationLink(destination: locationView(), tag: 1, selection: $selection) {
                                            Button(action: {
                                                if self.currentCount < sampleonbordingPages.count - 1 {
                                                    self.currentCount += 1
                                                }
                                                else{
                                                    
                                                    
                                                    
                                                    
                                                }
                                            })
                                
                                        {
                                             Text(currentCount < sampleonbordingPages.count - 1 ? "التالي" : "تصفح الآن")
                                                .padding(16)
                                                .frame(width: 200, height: 60)
                                                .background(.ultraThinMaterial)
                                                .cornerRadius(20)
                                                .padding(.horizontal,16)
                                                .foregroundColor(.white)
                                                .shadow(radius: 10)
                                            
                                            
                                        }
                                        .buttonStyle(PlainButtonStyle())
                                    }
                                    .padding(.top ,500)
                                }//end Zs
                                .tag(index)
                                
                            }//end for
                        }//end tap
                        .frame(
                            width: UIScreen.main.bounds.width ,
                            height: UIScreen.main.bounds.height
                        )
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    }
                }

        .edgesIgnoringSafeArea(.all)
//            }
//        }
}//end of body
}//end of main view

struct onbordingView_Previews: PreviewProvider {
    static var previews: some View {
        
        OnbordingView()
        
    }
}


