//
//  tabBar.swift
//  TourismApp
//
//  Created by ِatheer on 17/07/1444 AH.
//

import SwiftUI

struct tabBar: View {
    @State var selectedIndex = 0
    let Icons:[String] = ["house" , "mappin" , "magnifyingglass" ]
    var body: some View {
        VStack{
            
            ZStack{
                
                switch selectedIndex {
                case 0 :
                    NavigationView{
                        
                    }
                default:
                    NavigationView{
                        SignUpView()
                    }
                }
            }
            Spacer()
            
            ZStack{
                
                HStack(){
                    
                    ForEach(0 ..< 3 , id: \.self ){index in
                        Spacer()
                        Button(action:{
                            self.selectedIndex = index
                        },label:{
                            Image(systemName: Icons[index] )
                                .fontWeight(.bold)
                                .font(.system(size: 20))
                                .foregroundColor(selectedIndex == index ? .black : .secondary.opacity(0.5))
                            
                        })
                        Spacer()
                    }
                    
                }
                
                .frame(width: 400 ,height: 60)
                .background(.ultraThinMaterial)
                
            }
          
            
        }
        
        
        
    }
}

struct tabBar_Previews: PreviewProvider {
    static var previews: some View {
        tabBar()
    }
}
