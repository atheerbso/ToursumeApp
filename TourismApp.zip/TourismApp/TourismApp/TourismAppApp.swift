//
//  TourismAppApp.swift
//  TourismApp
//
//  Created by ِatheer on 15/07/1444 AH.
//

import SwiftUI
import Firebase
@main
struct TourismAppApp: App {
    @StateObject private var viewModelObject = LocationViewModel()

    init() {
        FirebaseApp.configure()
        
    }
    var body: some Scene {
        WindowGroup{
            //ContentView()
//            OnbordingView()
            logInView()
            //SectionView()
            //tabBar()
//
//            locationView()
//                .environmentObject(LocationViewModel())

        }
    }
}
